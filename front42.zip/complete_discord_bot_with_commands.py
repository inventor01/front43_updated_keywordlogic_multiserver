#!/usr/bin/env python3
"""
Front 42 - Simplified Discord Bot with 5 Essential Commands
Commands: add, remove, undo, list, clear
"""

import discord
from discord.ext import commands
import asyncio
import psycopg2
import os
import requests
import json
import time
from datetime import datetime, timedelta
import logging
from typing import Optional, Dict, List

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DatabaseManager:
    def __init__(self):
        # Railway database connection
        self.database_url = 'postgresql://postgres:TAmpBPYHVAnWDQaLeftFUmpDIBReQHqi@crossover.proxy.rlwy.net:40211/railway'
    
    def get_connection(self):
        try:
            return psycopg2.connect(self.database_url)
        except Exception as e:
            logger.error(f"Database connection failed: {e}")
            return None

class TokenMonitorBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        super().__init__(command_prefix='!', intents=intents)
        self.db = DatabaseManager()
        self.webhook_url = 'https://discord.com/api/webhooks/1390545562746490971/zODF3Er5XaSykD6Jl5IkxKiNqr_ArUCzj0DeH8PaDybGD1fXKKg3vr9xsxt_2jPti9yJ'
        self.undo_history = {}  # Track all actions per user for comprehensive undo
        
    async def setup_hook(self):
        try:
            synced = await self.tree.sync()
            logger.info(f'✅ Synced {len(synced)} slash commands')
            
            # Send startup notification
            embed = {
                'title': '🤖 Front 42 Bot ACTIVATED!',
                'description': f'5 Essential commands ready to use',
                'color': 0x00ff41,
                'fields': [
                    {'name': '✅ Status', 'value': 'Bot connected and ready', 'inline': False},
                    {'name': '📊 Commands', 'value': 'add, remove, undo, list, clear', 'inline': False}
                ]
            }
            
            try:
                requests.post(self.webhook_url, json={'embeds': [embed]})
            except:
                pass
                
        except Exception as e:
            logger.error(f'Command sync failed: {e}')

    async def on_ready(self):
        logger.info(f'Front 42 Discord Bot Active: {self.user}')
        logger.info(f'Connected to {len(self.guilds)} servers')

bot = TokenMonitorBot()

# ==================== 5 ESSENTIAL COMMANDS ====================

@bot.tree.command(name="add", description="Add a keyword to monitor")
async def add_keyword(interaction: discord.Interaction, keyword: str):
    """Add a keyword for token monitoring"""
    try:
        await interaction.response.defer()
        
        user_id = str(interaction.user.id)
        keyword = keyword.lower().strip()
        
        if not keyword or len(keyword) < 2:
            await interaction.followup.send("❌ Keyword must be at least 2 characters long")
            return
        
        conn = bot.db.get_connection()
        if not conn:
            await interaction.followup.send("❌ Database connection failed")
            return
            
        cursor = conn.cursor()
        
        # Check if keyword already exists for this user
        cursor.execute("SELECT 1 FROM keywords WHERE user_id = %s AND keyword = %s", (user_id, keyword))
        if cursor.fetchone():
            await interaction.followup.send(f"⚠️ Keyword '{keyword}' already exists")
            cursor.close()
            conn.close()
            return
        
        # Add keyword
        cursor.execute(
            "INSERT INTO keywords (user_id, keyword, created_at) VALUES (%s, %s, %s)",
            (user_id, keyword, datetime.now())
        )
        conn.commit()
        
        # Count total keywords for user
        cursor.execute("SELECT COUNT(*) FROM keywords WHERE user_id = %s", (user_id,))
        total_keywords = cursor.fetchone()[0]
        
        cursor.close()
        conn.close()
        
        embed = discord.Embed(
            title="✅ Keyword Added",
            description=f"Now monitoring: **{keyword}**",
            color=0x00ff41,
            timestamp=datetime.now()
        )
        embed.add_field(name="📊 Total Keywords", value=f"{total_keywords}", inline=True)
        embed.add_field(name="👤 User", value=f"<@{interaction.user.id}>", inline=True)
        
        # Store action for undo
        bot.undo_history[user_id] = {
            'action': 'add',
            'keyword': keyword,
            'timestamp': datetime.now()
        }
        
        await interaction.followup.send(embed=embed)
        
    except Exception as e:
        await interaction.followup.send(f"❌ Error adding keyword: {str(e)}")

@bot.tree.command(name="remove", description="Remove a keyword from monitoring")
async def remove_keyword(interaction: discord.Interaction, keyword: str):
    """Remove a keyword from monitoring"""
    try:
        await interaction.response.defer()
        
        user_id = str(interaction.user.id)
        keyword = keyword.lower().strip()
        
        conn = bot.db.get_connection()
        if not conn:
            await interaction.followup.send("❌ Database connection failed")
            return
            
        cursor = conn.cursor()
        
        # Check if keyword exists
        cursor.execute("SELECT keyword FROM keywords WHERE user_id = %s AND keyword = %s", (user_id, keyword))
        existing = cursor.fetchone()
        
        if not existing:
            await interaction.followup.send(f"❌ Keyword '{keyword}' not found")
            cursor.close()
            conn.close()
            return
        
        # Store action for undo
        bot.undo_history[user_id] = {
            'action': 'remove',
            'keyword': keyword,
            'timestamp': datetime.now()
        }
        
        # Remove keyword
        cursor.execute("DELETE FROM keywords WHERE user_id = %s AND keyword = %s", (user_id, keyword))
        conn.commit()
        
        # Count remaining keywords
        cursor.execute("SELECT COUNT(*) FROM keywords WHERE user_id = %s", (user_id,))
        remaining_keywords = cursor.fetchone()[0]
        
        cursor.close()
        conn.close()
        
        embed = discord.Embed(
            title="🗑️ Keyword Removed",
            description=f"Stopped monitoring: **{keyword}**",
            color=0xff6b6b,
            timestamp=datetime.now()
        )
        embed.add_field(name="📊 Remaining Keywords", value=f"{remaining_keywords}", inline=True)
        embed.add_field(name="↩️ Tip", value="Use `/undo` to restore this keyword", inline=True)
        
        await interaction.followup.send(embed=embed)
        
    except Exception as e:
        await interaction.followup.send(f"❌ Error removing keyword: {str(e)}")

@bot.tree.command(name="undo", description="Undo the last action (add, remove, or clear)")
async def undo_keyword(interaction: discord.Interaction):
    """Undo the last action (add, remove, or clear)"""
    try:
        await interaction.response.defer()
        
        user_id = str(interaction.user.id)
        
        if user_id not in bot.undo_history:
            await interaction.followup.send("❌ No recent action to undo")
            return
            
        last_action = bot.undo_history[user_id]
        action_type = last_action['action']
        
        conn = bot.db.get_connection()
        if not conn:
            await interaction.followup.send("❌ Database connection failed")
            return
            
        cursor = conn.cursor()
        
        if action_type == 'add':
            # Undo an add action (remove the keyword)
            keyword = last_action['keyword']
            cursor.execute("DELETE FROM keywords WHERE user_id = %s AND keyword = %s", (user_id, keyword))
            conn.commit()
            
            cursor.execute("SELECT COUNT(*) FROM keywords WHERE user_id = %s", (user_id,))
            remaining_keywords = cursor.fetchone()[0]
            
            embed = discord.Embed(
                title="↩️ Add Action Undone",
                description=f"Removed recently added keyword: **{keyword}**",
                color=0xff6b6b,
                timestamp=datetime.now()
            )
            embed.add_field(name="📊 Remaining Keywords", value=f"{remaining_keywords}", inline=True)
            
        elif action_type == 'remove':
            # Undo a remove action (restore the keyword)
            keyword = last_action['keyword']
            
            # Check if keyword was re-added manually
            cursor.execute("SELECT 1 FROM keywords WHERE user_id = %s AND keyword = %s", (user_id, keyword))
            if cursor.fetchone():
                await interaction.followup.send(f"⚠️ Keyword '{keyword}' already exists")
                cursor.close()
                conn.close()
                return
            
            cursor.execute(
                "INSERT INTO keywords (user_id, keyword, created_at) VALUES (%s, %s, %s)",
                (user_id, keyword, datetime.now())
            )
            conn.commit()
            
            cursor.execute("SELECT COUNT(*) FROM keywords WHERE user_id = %s", (user_id,))
            total_keywords = cursor.fetchone()[0]
            
            embed = discord.Embed(
                title="↩️ Removal Undone",
                description=f"Restored keyword: **{keyword}**",
                color=0x00ff41,
                timestamp=datetime.now()
            )
            embed.add_field(name="📊 Total Keywords", value=f"{total_keywords}", inline=True)
            
        elif action_type == 'clear':
            # Undo a clear action (restore all keywords)
            keywords_to_restore = last_action['keywords']
            
            for keyword in keywords_to_restore:
                cursor.execute(
                    "INSERT INTO keywords (user_id, keyword, created_at) VALUES (%s, %s, %s)",
                    (user_id, keyword, datetime.now())
                )
            conn.commit()
            
            cursor.execute("SELECT COUNT(*) FROM keywords WHERE user_id = %s", (user_id,))
            total_keywords = cursor.fetchone()[0]
            
            embed = discord.Embed(
                title="↩️ Clear Action Undone",
                description=f"Restored **{len(keywords_to_restore)}** keywords from clear operation",
                color=0x00ff41,
                timestamp=datetime.now()
            )
            embed.add_field(name="📊 Total Keywords", value=f"{total_keywords}", inline=True)
            embed.add_field(name="📝 Restored", value=f"{', '.join(keywords_to_restore[:5])}{'...' if len(keywords_to_restore) > 5 else ''}", inline=False)
        
        # Clear undo history after successful undo
        del bot.undo_history[user_id]
        
        cursor.close()
        conn.close()
        
        await interaction.followup.send(embed=embed)
        
    except Exception as e:
        await interaction.followup.send(f"❌ Error restoring keyword: {str(e)}")

@bot.tree.command(name="list", description="List all your monitored keywords")
async def list_keywords(interaction: discord.Interaction):
    """List all keywords being monitored by the user"""
    try:
        await interaction.response.defer()
        
        user_id = str(interaction.user.id)
        
        conn = bot.db.get_connection()
        if not conn:
            await interaction.followup.send("❌ Database connection failed")
            return
            
        cursor = conn.cursor()
        cursor.execute(
            "SELECT keyword, created_at FROM keywords WHERE user_id = %s ORDER BY created_at DESC",
            (user_id,)
        )
        keywords = cursor.fetchall()
        cursor.close()
        conn.close()
        
        if not keywords:
            await interaction.followup.send("📝 No keywords found. Use `/add <keyword>` to start monitoring.")
            return
        
        # Format keywords for display
        keyword_list = []
        for i, (keyword, created_at) in enumerate(keywords, 1):
            formatted_date = created_at.strftime("%m/%d")
            keyword_list.append(f"{i}. **{keyword}** *(added {formatted_date})*")
        
        # Split into chunks if too many keywords
        chunks = [keyword_list[i:i+10] for i in range(0, len(keyword_list), 10)]
        
        for chunk_idx, chunk in enumerate(chunks):
            embed = discord.Embed(
                title=f"📝 Your Keywords {f'(Page {chunk_idx + 1})' if len(chunks) > 1 else ''}",
                description="\n".join(chunk),
                color=0x3498db,
                timestamp=datetime.now()
            )
            embed.add_field(name="📊 Total", value=f"{len(keywords)} keywords", inline=True)
            embed.add_field(name="👤 User", value=f"<@{interaction.user.id}>", inline=True)
            
            if chunk_idx == 0:
                await interaction.followup.send(embed=embed)
            else:
                await interaction.followup.send(embed=embed)
        
    except Exception as e:
        await interaction.followup.send(f"❌ Error listing keywords: {str(e)}")

@bot.tree.command(name="clear", description="Remove ALL your keywords (use with caution)")
async def clear_keywords(interaction: discord.Interaction, confirm: str):
    """Clear all keywords for the user (requires confirmation)"""
    try:
        await interaction.response.defer()
        
        user_id = str(interaction.user.id)
        
        # Require exact confirmation
        if confirm.lower() != "yes i want to delete all":
            embed = discord.Embed(
                title="⚠️ Confirmation Required",
                description="To clear ALL your keywords, use:\n`/clear confirm: yes i want to delete all`",
                color=0xffa500
            )
            embed.add_field(name="⚠️ Warning", value="This action cannot be undone", inline=False)
            await interaction.followup.send(embed=embed)
            return
        
        conn = bot.db.get_connection()
        if not conn:
            await interaction.followup.send("❌ Database connection failed")
            return
            
        cursor = conn.cursor()
        
        # Get all keywords before deletion for undo functionality
        cursor.execute("SELECT keyword FROM keywords WHERE user_id = %s", (user_id,))
        keywords_to_delete = [row[0] for row in cursor.fetchall()]
        
        if not keywords_to_delete:
            await interaction.followup.send("📝 No keywords to clear")
            cursor.close()
            conn.close()
            return
        
        # Store action for undo before deletion
        bot.undo_history[user_id] = {
            'action': 'clear',
            'keywords': keywords_to_delete,
            'timestamp': datetime.now()
        }
        
        # Delete all keywords for user
        cursor.execute("DELETE FROM keywords WHERE user_id = %s", (user_id,))
        conn.commit()
        keyword_count = len(keywords_to_delete)
        
        cursor.close()
        conn.close()
        
        # Note: Undo history is preserved for clear operations
        
        embed = discord.Embed(
            title="🗑️ Keywords Cleared",
            description=f"Removed **{keyword_count}** keywords from monitoring",
            color=0xff6b6b,
            timestamp=datetime.now()
        )
        embed.add_field(name="📊 Status", value="No keywords active", inline=True)
        embed.add_field(name="➕ Next Step", value="Use `/add` to start monitoring", inline=True)
        embed.add_field(name="↩️ Tip", value="Use `/undo` to restore all keywords", inline=True)
        
        await interaction.followup.send(embed=embed)
        
    except Exception as e:
        await interaction.followup.send(f"❌ Error clearing keywords: {str(e)}")

# ==================== BOT STARTUP ====================

async def main():
    """Main function to start the bot"""
    try:
        token = os.getenv('DISCORD_TOKEN')
        if not token:
            logger.error("❌ DISCORD_TOKEN environment variable not found")
            return
        
        logger.info("🤖 Starting Front 42 Discord Bot with 5 commands...")
        logger.info(f"🔑 Using token: {token[:30]}...{token[-10:]}")
        
        await bot.start(token)
        
    except discord.errors.LoginFailure:
        logger.error("❌ Bot failed to start: Improper token has been passed.")
        logger.error("💡 Check if token is valid and bot has required permissions")
    except Exception as e:
        logger.error(f"❌ Bot startup failed: {e}")

if __name__ == "__main__":
    asyncio.run(main())